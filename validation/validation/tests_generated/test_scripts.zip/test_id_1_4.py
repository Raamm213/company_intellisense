import pytest
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple

# ============================================================
# DATA MODELS
# ============================================================

@dataclass
class Parameter:
    parameter_id: str
    name: str
    value: Any
    metadata: Dict[str, Any]


@dataclass
class Dataset:
    parameters: List[Parameter]


# ============================================================
# MASTER TEST STRUCTURE
# ============================================================

class Applicability:
    CONDITIONAL = "conditional"


class MasterTestCase:
    def __init__(self, test_id: str, applicability: str, condition, validator):
        self.test_id = test_id
        self.applicability = applicability
        self.condition = condition
        self.validator = validator


# ============================================================
# CONDITION — Applies Only To Company Name
# ============================================================

def company_name_condition(param: Parameter) -> bool:
    return param.name == "Company Name"


# ============================================================
# TC-1.4-COMPANYNAME-01
# Misspelled company name
# ============================================================

OFFICIAL_COMPANY_NAMES = {
    "Microsoft Corporation",
    "Apple Inc.",
    "Google LLC",
    "Tesla, Inc.",
    # ... expand with actual registry list
}


def tc_1_4_companyname_01_validator(param: Parameter):
    value = param.value
    if value not in OFFICIAL_COMPANY_NAMES:
        return (
            "Violates business rule: Must match official government registration documents"
        )
    return True


TC_1_4_COMPANYNAME_01 = MasterTestCase(
    test_id="TC-1.4-COMPANYNAME-01",
    applicability=Applicability.CONDITIONAL,
    condition=company_name_condition,
    validator=tc_1_4_companyname_01_validator
)


# ============================================================
# TC-1.4-COMPANYNAME-02
# Incomplete company name
# ============================================================

def tc_1_4_companyname_02_validator(param: Parameter):
    value = param.value
    if len(value.strip().split()) < 2:
        return "Below minimum legal identity completeness"
    return True


TC_1_4_COMPANYNAME_02 = MasterTestCase(
    test_id="TC-1.4-COMPANYNAME-02",
    applicability=Applicability.CONDITIONAL,
    condition=company_name_condition,
    validator=tc_1_4_companyname_02_validator
)


# ============================================================
# TC-1.4-COMPANYNAME-03
# Abbreviated / truncated company name
# ============================================================

def tc_1_4_companyname_03_validator(param: Parameter):
    value = param.value
    if value not in OFFICIAL_COMPANY_NAMES:
        return "Must match official registered company name"
    return True


TC_1_4_COMPANYNAME_03 = MasterTestCase(
    test_id="TC-1.4-COMPANYNAME-03",
    applicability=Applicability.CONDITIONAL,
    condition=company_name_condition,
    validator=tc_1_4_companyname_03_validator
)


# ============================================================
# TC-1.4-COMPANYNAME-04
# Phonetic misspelling
# ============================================================

def tc_1_4_companyname_04_validator(param: Parameter):
    value = param.value

    # Optional: Levenshtein distance or phonetic match (simplified here)
    # If exact match fails, flag
    if value not in OFFICIAL_COMPANY_NAMES:
        return "Does not match official registration record (possible phonetic misspelling)"
    return True


TC_1_4_COMPANYNAME_04 = MasterTestCase(
    test_id="TC-1.4-COMPANYNAME-04",
    applicability=Applicability.CONDITIONAL,
    condition=company_name_condition,
    validator=tc_1_4_companyname_04_validator
)


# ============================================================
# TC-1.4-COMPANYNAME-05
# Truncated legal suffix
# ============================================================

LEGAL_SUFFIXES = ["Inc.", "Ltd.", "Corp.", "LLC"]

def tc_1_4_companyname_05_validator(param: Parameter):
    value = param.value
    if not any(value.endswith(suffix) for suffix in LEGAL_SUFFIXES):
        return "Missing legal suffix (Inc., Ltd., Corp.)"
    return True


TC_1_4_COMPANYNAME_05 = MasterTestCase(
    test_id="TC-1.4-COMPANYNAME-05",
    applicability=Applicability.CONDITIONAL,
    condition=company_name_condition,
    validator=tc_1_4_companyname_05_validator
)


# ============================================================
# REGISTER ALL TEST CASES
# ============================================================

ALL_1_4_COMPANYNAME_TESTS = [
    TC_1_4_COMPANYNAME_01,
    TC_1_4_COMPANYNAME_02,
    TC_1_4_COMPANYNAME_03,
    TC_1_4_COMPANYNAME_04,
    TC_1_4_COMPANYNAME_05
]


# ============================================================
# RULE ENGINE
# ============================================================

def evaluate_conditional(test_case: MasterTestCase, dataset: Dataset) -> List[Tuple[str, str]]:
    failures = []

    for param in dataset.parameters:
        if test_case.condition(param):
            result = test_case.validator(param)
            if result is not True:
                failures.append((param.parameter_id, result))

    return failures


# ============================================================
# PYTEST FIXTURE (Replace with real loader)
# ============================================================

@pytest.fixture
def dataset():
    return Dataset(parameters=[
        Parameter("P001", "Company Name", "Microsft Corporation", {}),
        Parameter("P002", "Company Name", "App", {}),
        Parameter("P003", "Company Name", "Goog", {}),
        Parameter("P004", "Company Name", "Mikrosoft Corp", {}),
        Parameter("P005", "Company Name", "Tesla", {})
    ])


# ============================================================
# PYTEST EXECUTION
# ============================================================

@pytest.mark.parametrize("test_case", ALL_1_4_COMPANYNAME_TESTS)
def test_company_name_business_rules(dataset, test_case):
    failures = evaluate_conditional(test_case, dataset)

    assert not failures, (
        f"\nValidation Failure\n"
        f"Test Case: {test_case.test_id}\n"
        f"Failures:\n" +
        "\n".join(
            f"Parameter {pid}: {reason}" for pid, reason in failures
        )
    )