import copy

import pytest

from validation_utils import (
    load_companies,
    load_mapping,
    load_metadata,
    load_spec_rows,
    parse_expected_outcome,
    validate_field_value,
)


RULES = load_metadata()
MAPPING = load_mapping()
COMPANIES = load_companies()
CASES = load_spec_rows("ID 2.4.csv")


@pytest.mark.parametrize("row", CASES, ids=[row["Test ID"] for row in CASES])
def test_mandatory_fields_only(row: dict) -> None:
    record = copy.deepcopy(COMPANIES[0])
    column_name = row.get("column_name", "").strip()
    expected = parse_expected_outcome(row.get("Expected Result", ""))

    csv_header = MAPPING.get(column_name, "")
    if not csv_header:
        pytest.skip(f"No CSV mapping for {column_name}")

    # Simulate NULL or missing key.
    record.pop(csv_header, None)

    rule = RULES.get(column_name)
    if rule is None:
        pytest.skip(f"No metadata rule for {column_name}")

    errors = validate_field_value(column_name, None, rule)

    if expected == "pass":
        assert not errors, f"{row['Test ID']}: {errors}"
    else:
        assert errors, f"{row['Test ID']}: expected errors but got none"
