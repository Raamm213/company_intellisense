import pytest

from validation_utils import load_spec_rows


CASES = load_spec_rows("ID 3.1.csv")


@pytest.mark.parametrize("row", CASES, ids=[row["Test ID"] for row in CASES])
def test_factual_correctness_requires_external_sources(row: dict) -> None:
    pytest.skip(f"{row['Test ID']}: requires external data validation")
